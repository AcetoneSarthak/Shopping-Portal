package com.payment_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDetailsRequest {
	
	String paymentId;
	String orderId;
	String customerId;
	
	@CreationTimestamp
	LocalDateTime paymentTime;
	
	String paymentStatus;
	
	double paymentAmount;
	
	String currency;

	public PaymentDetailsRequest(String paymentId, String orderId, String customerId, LocalDateTime paymentTime,
			String paymentStatus, double paymentAmount, String currency) {
		super();
		this.paymentId = paymentId;
		this.orderId = orderId;
		this.customerId = customerId;
		this.paymentTime = paymentTime;
		this.paymentStatus = paymentStatus;
		this.paymentAmount = paymentAmount;
		this.currency = currency;
	}


	public String getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}


	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDateTime getPaymentTime() {
		return paymentTime;
	}

	public void setPaymentTime(LocalDateTime paymentTime) {
		this.paymentTime = paymentTime;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
