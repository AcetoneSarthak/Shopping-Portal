package com.payment_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

public class PaymentDetailsResponse {
	
	String paymentId;
	String orderId;
	String customerId;
	
	@CreationTimestamp
	LocalDateTime payment_time;
	
	String payment_status;
	
	BigDecimal payment_amount;
	
	String currency;

	public PaymentDetailsResponse() {
		super();
	}

	public PaymentDetailsResponse(String paymentId, String orderId, String customerId, LocalDateTime payment_time,
			String payment_status, BigDecimal payment_amount, String currency) {
		super();
		this.paymentId = paymentId;
		this.orderId = orderId;
		this.customerId = customerId;
		this.payment_time = payment_time;
		this.payment_status = payment_status;
		this.payment_amount = payment_amount;
		this.currency = currency;
	}

	@Override
	public String toString() {
		return "PaymentDetailsResponse [paymentId=" + paymentId + ", orderId=" + orderId + ", customerId=" + customerId
				+ ", payment_time=" + payment_time + ", payment_status=" + payment_status + ", payment_amount="
				+ payment_amount + ", currency=" + currency + "]";
	}
	
	


}
