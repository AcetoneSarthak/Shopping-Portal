package com.payment_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.payment_service.dto.PaymentDetailsRequest;
import com.payment_service.dto.PaymentDetailsResponse;
import com.payment_service.service.PaymentDetailsServiceImpl;
import com.payment_service.model.PaymentDetails;

@RestController
@RequestMapping("/payment-service")
public class PaymentDetailsController {

	@Autowired
	PaymentDetailsServiceImpl paymentDetailsService;
	
	
  @PostMapping("/savePaymentDetails")
  @ResponseStatus(HttpStatus.CREATED)
  public void savePaymentDetails(@RequestBody PaymentDetailsRequest paymentDetailsRequest)
  {
	  paymentDetailsService.savePaymentDetails(paymentDetailsRequest);
  }
  
  @GetMapping("/getPaymentDetails/{orderId}")
  public List<PaymentDetails> getPaymentDetails(@PathVariable("orderId") String orderId) throws InterruptedException
  {
	  Thread.sleep(5000);
	  return paymentDetailsService.getPaymentDetails(orderId);
	  
  }
  
   
}
