package com.payment_service.exception;

import java.time.LocalDateTime;

public class ExceptionBody {

	String message;
	int code;
	LocalDateTime timestamp;
	public ExceptionBody(String message, int code, LocalDateTime timestamp) {
		super();
		this.message = message;
		this.code = code;
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	
	
	
}
