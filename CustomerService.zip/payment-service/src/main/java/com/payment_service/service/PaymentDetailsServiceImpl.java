package com.payment_service.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.payment_service.dto.PaymentDetailsRequest;
import com.payment_service.dto.PaymentDetailsResponse;
import com.payment_service.model.PaymentDetails;
import com.payment_service.repository.PaymentDetailsRepository;

@Service
public class PaymentDetailsServiceImpl implements PaymentDetailsService{

	@Autowired
	PaymentDetailsRepository paymentDetailsRepository;
	
	 public void savePaymentDetails(PaymentDetailsRequest paymentDetailsRequest)
	  {
		 PaymentDetails paymentDetails = new PaymentDetails();
		 paymentDetails.setId(paymentDetailsRequest.getPaymentId());
		 paymentDetails.setCustomerId(paymentDetailsRequest.getCustomerId());
		 paymentDetails.setOrderId(paymentDetailsRequest.getOrderId());
		 paymentDetails.setPaymentAmount(paymentDetailsRequest.getPaymentAmount());
		 paymentDetails.setPaymentStatus(paymentDetailsRequest.getPaymentStatus());
		 paymentDetails.setPaymentTime(paymentDetailsRequest.getPaymentTime());
		 paymentDetails.setCurrency(paymentDetailsRequest.getCurrency());
		 
		 paymentDetailsRepository.save(paymentDetails);
		 
		 
	  }
	 
	 public List<PaymentDetails> getPaymentDetails(String orderId)
	 {
		 
		return paymentDetailsRepository.findByOrderId(orderId);
	 }
	 
}
