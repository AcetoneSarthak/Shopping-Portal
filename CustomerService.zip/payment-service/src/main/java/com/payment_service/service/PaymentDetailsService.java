package com.payment_service.service;

import java.util.List;

import com.payment_service.dto.PaymentDetailsRequest;
import com.payment_service.model.PaymentDetails;

public interface PaymentDetailsService {

	 public void savePaymentDetails(PaymentDetailsRequest paymentDetailsRequest);
	 
	 public List<PaymentDetails> getPaymentDetails(String customerId);

}
