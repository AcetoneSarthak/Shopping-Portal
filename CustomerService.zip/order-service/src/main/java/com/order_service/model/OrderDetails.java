package com.order_service.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "order_details", schema = "orders")
public class OrderDetails {
	
	@Id
	String id;
	
	@Column(name="customer_id")
	String customerId;
	
	@Column(name="delivery_date")
	LocalDate deliveryDate;
	
	@Column(name="product_id")
	String productiId ;
	
	@Column(name="product_category")
	String productCategory;
	
	@Column(name="product_name")
	String productName;
	
	@Column(name="order_date")
	LocalDate orderdate;
	
	@Column(name = "quantity")
	int quantity;
	
	

	public OrderDetails() {
		super();
	}

	public OrderDetails(String id, String customerId, LocalDate deliveryDate, String productiId, String productCategory,
			String productName, LocalDate orderdate, int quantity) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.deliveryDate = deliveryDate;
		this.productiId = productiId;
		this.productCategory = productCategory;
		this.productName = productName;
		this.orderdate = orderdate;
		this.quantity = quantity;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getProductiId() {
		return productiId;
	}

	public void setProductiId(String productiId) {
		this.productiId = productiId;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "OrderDetails [id=" + id + ", customerId=" + customerId + ", deliveryDate=" + deliveryDate
				+ ", productiId=" + productiId + ", productCategory=" + productCategory + ", productName=" + productName
				+ ", orderdate=" + orderdate + ", quantity=" + quantity + "]";
	}
  
	
	
	
}
