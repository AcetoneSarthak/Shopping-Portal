package com.order_service.service;

import java.util.List;

import com.order_service.dto.OrderDetailsRequest;
import com.order_service.model.OrderDetails;

public interface OrderDetailsService {
	
	 public void saveOrderDetails(OrderDetailsRequest orderDetailsRequest);
	 
	 public List<OrderDetails> getOrderDetails(String customerId);

}
