package com.customer_service.dto;

import java.util.List;

import org.springframework.stereotype.Component;

import com.customer_service.model.Customer;

@Component
public class ViewCustomerDetails {

	Customer customer;
	
	List<Orders> orders;

	public ViewCustomerDetails() {
		super();
	}

	public ViewCustomerDetails(Customer customer, List<Orders> orders) {
		super();
		this.customer = customer;
		this.orders = orders;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

	@Override
	public String toString() {
		return "ViewCustomerDetails [customer=" + customer + ", orders=" + orders + "]";
	}
	
	
}
