package com.customer_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

@Component
public class PaymentDetails {

    String paymentId;
	String orderId;
	String customerId;
	
	@CreationTimestamp
	LocalDateTime payment_time;
	
	String payment_status;
	
	double payment_amount;
	
	String currency;

	public PaymentDetails() {
		super();
	}

	public PaymentDetails(String paymentId, String orderId, String customerId, LocalDateTime payment_time,
			String payment_status, double payment_amount, String currency) {
		super();
		this.paymentId = paymentId;
		this.orderId = orderId;
		this.customerId = customerId;
		this.payment_time = payment_time;
		this.payment_status = payment_status;
		this.payment_amount = payment_amount;
		this.currency = currency;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDateTime getPayment_time() {
		return payment_time;
	}

	public void setPayment_time(LocalDateTime payment_time) {
		this.payment_time = payment_time;
	}

	public String getPayment_status() {
		return payment_status;
	}

	public void setPayment_status(String payment_status) {
		this.payment_status = payment_status;
	}

	public double getPayment_amount() {
		return payment_amount;
	}

	public void setPayment_amount(double payment_amount) {
		this.payment_amount = payment_amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	
}
