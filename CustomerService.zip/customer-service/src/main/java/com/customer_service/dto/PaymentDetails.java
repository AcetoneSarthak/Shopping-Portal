package com.customer_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

@Component
public class PaymentDetails {

    String id;
	String orderId;
	String customerId;
	
	@CreationTimestamp
	LocalDateTime paymentTime;
	
	String paymentStatus;
	
	double paymentAmount;
	
	String currency;

	public PaymentDetails() {
		super();
	}

	public PaymentDetails(String id, String orderId, String customerId, LocalDateTime paymentTime, String paymentStatus,
			double paymentAmount, String currency) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.customerId = customerId;
		this.paymentTime = paymentTime;
		this.paymentStatus = paymentStatus;
		this.paymentAmount = paymentAmount;
		this.currency = currency;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDateTime getPaymentTime() {
		return paymentTime;
	}

	public void setPaymentTime(LocalDateTime paymentTime) {
		this.paymentTime = paymentTime;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@Override
	public String toString() {
		return "PaymentDetails [id=" + id + ", orderId=" + orderId + ", customerId=" + customerId + ", paymentTime="
				+ paymentTime + ", paymentStatus=" + paymentStatus + ", paymentAmount=" + paymentAmount + ", currency="
				+ currency + "]";
	}

	
}
