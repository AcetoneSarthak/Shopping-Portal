package com.customer_service.dto;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Orders {
	
	OrderDetails OrderDetails;
	
	List<PaymentDetails> paymentDetails;

	public Orders() {
		super();
	}

	public Orders(OrderDetails orderDetails, List<PaymentDetails> paymentDetails) {
		OrderDetails = orderDetails;
		this.paymentDetails = paymentDetails;
	}

	public OrderDetails getOrderDetails() {
		return OrderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		OrderDetails = orderDetails;
	}

	public List<PaymentDetails> getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(List<PaymentDetails> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	@Override
	public String toString() {
		return "Orders [OrderDetails=" + OrderDetails + ", paymentDetails=" + paymentDetails + "]";
	}
	
	
	
	

}
