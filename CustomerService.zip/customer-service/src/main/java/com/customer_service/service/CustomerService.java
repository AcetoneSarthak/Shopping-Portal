package com.customer_service.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.customer_service.dto.OrderDetails;
import com.customer_service.dto.Orders;
import com.customer_service.dto.PaymentDetails;
import com.customer_service.dto.ViewCustomerDetails;
import com.customer_service.exception.CustomerNotFound;
import com.customer_service.model.Customer;
import com.customer_service.repository.CustomerRepository;

import jakarta.persistence.criteria.Order;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	
	
	OrderServiceCaller orderServiceCaller;
	PaymentServiceCaller paymentServiceCaller;
	    
	public CustomerService(OrderServiceCaller orderServiceCaller,PaymentServiceCaller paymentServiceCaller) {
	this.orderServiceCaller = orderServiceCaller;
	this.paymentServiceCaller = paymentServiceCaller;
		}

		List<Orders> ordersList = new ArrayList<>();
		
		
		
		public ViewCustomerDetails viewCustomerOrderDetails(String customerId)throws InterruptedException, ExecutionException, CustomerNotFound
		{ 
			  Optional<Customer> customer = Optional.ofNullable(new Customer());
			 			  
			  customer= customerRepository.findById(customerId);
			  if(!customer.isPresent())
			  {
				  throw new CustomerNotFound("Customer Not Found");
			  }
			  ViewCustomerDetails viewCustomerDetails = new ViewCustomerDetails();
			  viewCustomerDetails.setCustomer(customer.get());
		
			  
			  
			  
			  List<OrderDetails> orderList = orderServiceCaller.getOrderByCustomerID(customerId).get();
				
				
				for(OrderDetails o : orderList )
				{
					List<PaymentDetails> paymentList = paymentServiceCaller.getPaymentDetailsByOrderID(o.getid()).get();
					
					
					
					ordersList.add(new Orders(o,paymentList));
					
				}
				
				
				viewCustomerDetails.setOrders(ordersList);
				
				
				return viewCustomerDetails;
		}
	
}
