package com.customer_service.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.customer_service.dto.OrderDetails;
import com.fasterxml.jackson.databind.ObjectMapper;


@Service
public class OrderServiceCaller {


	@Autowired
	@Qualifier("orderWebClient")
	private WebClient webClientForOrderService;
	
	@Autowired
	RestTemplate rt;
	
	
	@Async("asyncTaskExecutor")
	public CompletableFuture<List<OrderDetails>> getOrderByCustomerID(String customerId)
	{
		
		
		List<OrderDetails> listOfOrders = webClientForOrderService.get()
		.uri("/getOrderDetails/{customerId}", customerId)
		.retrieve()
		.bodyToFlux(OrderDetails.class).collectList().block();
		
		return CompletableFuture.completedFuture(listOfOrders);
		
	}
}
