package com.customer_service.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.customer_service.dto.OrderDetails;
import com.customer_service.dto.ViewCustomerDetails;
import com.customer_service.model.Customer;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


@Service
public class OrderServiceCaller {

	@Value("${orderservice.base.url}")
	String orderServiceBaseUrl;
	
	
	private WebClient webClientForOrderService;
	
	
	
	public OrderServiceCaller(WebClient.Builder webClientBuilder)
	{
		this.webClientForOrderService=webClientBuilder.baseUrl(orderServiceBaseUrl).build();
		
	}
	
/*	@Async("asyncTaskExecutor")
	public CompletableFuture<List<OrderDetails>> getOrderByCustomerID(String customerId)
	{
		
		
		List<OrderDetails> listOfOrders = webClientForOrderService.get()
		.uri("order-service/getOrderDetails/{customerId}", customerId)
		.retrieve()
		.bodyToFlux(OrderDetails.class).collectList().block();
		
		return CompletableFuture.completedFuture(listOfOrders);
		
		*/
	
	public List<OrderDetails> getOrderByCustomerID(String customerId)
	{
		
		System.out.println("Order SErvice URL " +orderServiceBaseUrl);
		
		List<OrderDetails> listOfOrders = webClientForOrderService.get()
		.uri("/order-service/getOrderDetails/{customerId}", customerId)
		.retrieve()
		.bodyToFlux(OrderDetails.class).collectList().block();
		
		System.out.println(listOfOrders.get(0));
		
		return listOfOrders;
		
	}
}
