package com.customer_service.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.customer_service.dto.OrderDetails;
import com.customer_service.dto.PaymentDetails;
import com.customer_service.dto.ViewCustomerDetails;
import com.customer_service.model.Customer;

import reactor.core.publisher.Flux;


@Service
public class PaymentServiceCaller {

	@Autowired
	@Qualifier("paymentWebClient")
	private WebClient webClientForPaymentService;
	
	
	
	
@Async("asyncTaskExecutor")
	public CompletableFuture<List<PaymentDetails>> getPaymentDetailsByOrderID(String orderId)
	{
		
		List<PaymentDetails> listOfPayments = webClientForPaymentService.get()
		.uri("/getPaymentDetails/{orderId}", orderId)
		.retrieve()
		.bodyToFlux(PaymentDetails.class).collectList().block();
		
		return CompletableFuture.completedFuture(listOfPayments);
		
	}
	
	
	
	
	
	
	/*
	
	public List<PaymentDetails> getPaymentDetailsByOrderID(String orderId)
	{
		
		List<PaymentDetails> listOfPayments = webClientForPaymentService.get()
		.uri("/getPaymentDetails/{orderId}", orderId)
		.retrieve()
		.bodyToFlux(PaymentDetails.class).collectList().block();
		
		return listOfPayments;
		
	}
	*/
	
}
