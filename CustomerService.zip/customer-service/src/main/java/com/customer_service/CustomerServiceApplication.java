package com.customer_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.customer_service.model.Customer;
import com.customer_service.repository.CustomerRepository;

@SpringBootApplication
public class CustomerServiceApplication implements CommandLineRunner{

	@Autowired
	CustomerRepository customerRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(CustomerServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
		Customer c1 = new Customer("CUS123","Sarthak","sarthakpawar@gmail.com");
		Customer c2 = new Customer("CUS124","Mustafa","mustafa@gmail.com");
		Customer c3 = new Customer("CUS125","Anjali","anjalisingh@gmail.com");
		
		customerRepository.save(c1);
		customerRepository.save(c2);
		customerRepository.save(c3);
		
		
	}

}
