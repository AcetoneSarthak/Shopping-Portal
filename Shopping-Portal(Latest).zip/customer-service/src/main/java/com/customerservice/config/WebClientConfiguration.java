package com.customerservice.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;


@Configuration
public class WebClientConfiguration {


	@Value("${orderservice.base.url}")
	String orderServiceBaseUrl;
	
	@Value("${paymentservice.base.url}")
	String paymentServiceBaseUrl;

    @Bean("orderWebClient")
    WebClient webClientForOrder() {
        return WebClient.builder().baseUrl(orderServiceBaseUrl)
        		.build();
    }
    
    @Bean("paymentWebClient")
    WebClient webClientForPayment() {
        return WebClient.builder().baseUrl(paymentServiceBaseUrl).build();
    }
    
 
	
}
