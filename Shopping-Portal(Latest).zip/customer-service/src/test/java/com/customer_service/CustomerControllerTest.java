package com.customer_service;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.customerservice.controller.CustomerController;
import com.customerservice.dto.OrderDetails;
import com.customerservice.dto.Orders;
import com.customerservice.dto.PaymentDetails;
import com.customerservice.dto.ViewCustomerDetails;
import com.customerservice.model.*;
import com.customerservice.repository.CustomerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(CustomerController.class)
@ExtendWith(MockitoExtension.class)
public class CustomerControllerTest {
	
	  @MockBean
	  private CustomerRepository customerRepository;
	

	  @Autowired
	  private MockMvc mockMvc;

	  @Autowired
	  private ObjectMapper objectMapper;
	  
	  @Test
	  void shouldReturnViewOfCustomerDetailsWithOrderDetails() throws Exception {
	    List<Customer> customers = new ArrayList<>(
	        Arrays.asList(new Customer("CUS123", "Sarthak", "sarthak@gmail.com"),
	        		new Customer("CUS124", "Mustafa", "mustafa@gmail.com"),
	        		new Customer("CUS125", "Aditi", "adiiti@gmail.com")));
	    
	    
	    PaymentDetails paymentDetails = new PaymentDetails();
	    paymentDetails.setCurrency("INR");
	    paymentDetails.setCustomerId("CUS123");
	    paymentDetails.setOrderId("ORD123");
	    paymentDetails.setPaymentAmount(200);
	    paymentDetails.setPaymentStatus("COMPLETED");
	    paymentDetails.setPaymentTime(LocalDateTime.now());
	    
	    Orders orders = new Orders();
	    orders.setCustomerId("CUS123");
	    orders.setDeliveryDate(LocalDate.now().plusDays(2));
	    orders.setOrderdate(LocalDate.now());
	    orders.setId("ORD123");
	    orders.setProductCategory("FMCG");
	    orders.setProductiId(UUID.randomUUID());
	    orders.setProductName("Lays");
	    orders.setQuantity(1);
	    
	    orders.setPaymentDetails(Arrays.asList(paymentDetails));
	    
	    ViewCustomerDetails viewCustomerDetails = new ViewCustomerDetails();
	    
	    viewCustomerDetails.setCustomer(customers.get(0));
	    viewCustomerDetails.setOrders(Arrays.asList(orders));
	    
	    

	    when(customerRepository.findAll()).thenReturn(customers);
	    
	    when(customerRepository.findById("CUS123").get()).thenReturn(customers.get(0));
	    
	    mockMvc.perform(get("/customer-service/viewCustomerOrders/CUS123"))
        .andExpect(status().isOk())
        .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(customers.get(0).getId()));
	    
	   
	  }

	 

}
