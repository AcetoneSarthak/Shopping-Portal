package com.orderservice.service;

import java.util.List;

import com.orderservice.dto.OrderDetailsRequest;
import com.orderservice.model.OrderDetails;

public interface OrderDetailsService {
	
	 public void saveOrderDetails(OrderDetailsRequest orderDetailsRequest);
	 
	 public List<OrderDetails> getOrderDetails(String customerId);

}
