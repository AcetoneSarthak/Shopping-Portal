package com.paymentservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.paymentservice.dto.PaymentDetailsRequest;
import com.paymentservice.dto.PaymentDetailsResponse;
import com.paymentservice.model.PaymentDetails;
import com.paymentservice.repository.PaymentDetailsRepository;

@Service
public class PaymentDetailsServiceImpl implements PaymentDetailsService{

	@Autowired
	PaymentDetailsRepository paymentDetailsRepository;
	
	 public void savePaymentDetails(PaymentDetailsRequest paymentDetailsRequest)
	  {
		 PaymentDetails paymentDetails = new PaymentDetails();
		 paymentDetails.setId(paymentDetailsRequest.getPaymentId());
		 paymentDetails.setCustomerId(paymentDetailsRequest.getCustomerId());
		 paymentDetails.setOrderId(paymentDetailsRequest.getOrderId());
		 paymentDetails.setPaymentAmount(paymentDetailsRequest.getPaymentAmount());
		 paymentDetails.setPaymentStatus(paymentDetailsRequest.getPaymentStatus());
		 paymentDetails.setPaymentTime(paymentDetailsRequest.getPaymentTime());
		 paymentDetails.setCurrency(paymentDetailsRequest.getCurrency());
		 
		 paymentDetailsRepository.save(paymentDetails);
		 
		 
	  }
	 
	 public List<PaymentDetails> getPaymentDetails(String orderId)
	 {
		 
		return paymentDetailsRepository.findByOrderId(orderId);
	 }

	public List<PaymentDetails> getPaymentDetailsByCustID(String customerId) {
		return paymentDetailsRepository.findByCustomerId(customerId);
		
	}
	 
}
