package com.paymentservice.service;

import java.util.List;

import com.paymentservice.dto.PaymentDetailsRequest;
import com.paymentservice.model.PaymentDetails;

public interface PaymentDetailsService {

	 public void savePaymentDetails(PaymentDetailsRequest paymentDetailsRequest);
	 
	 public List<PaymentDetails> getPaymentDetails(String customerId);

}
