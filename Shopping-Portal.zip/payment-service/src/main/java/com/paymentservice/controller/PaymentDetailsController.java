package com.paymentservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.paymentservice.dto.PaymentDetailsRequest;
import com.paymentservice.dto.PaymentDetailsResponse;
import com.paymentservice.model.PaymentDetails;
import com.paymentservice.service.PaymentDetailsServiceImpl;

@RestController
@RequestMapping("/payment-service")
public class PaymentDetailsController {

	@Autowired
	PaymentDetailsServiceImpl paymentDetailsService;
	
	
  @PostMapping("/savePaymentDetails")
  @ResponseStatus(HttpStatus.CREATED)
  public void savePaymentDetails(@RequestBody PaymentDetailsRequest paymentDetailsRequest)
  {
	  paymentDetailsService.savePaymentDetails(paymentDetailsRequest);
  }
  
  @GetMapping("/getPaymentDetails/{orderId}")
  public List<PaymentDetails> getPaymentDetails(@PathVariable("orderId") String orderId) throws InterruptedException
  {
	  Thread.sleep(5000);
	  return paymentDetailsService.getPaymentDetails(orderId);
	  
  }
  
  @GetMapping("/getPaymentDetailsByCustID/{customerId}")
  public List<PaymentDetails> getPaymentDetailsByCustID(@PathVariable("customerId") String customerId) throws InterruptedException
  {
	  Thread.sleep(5000);
	  return paymentDetailsService.getPaymentDetailsByCustID(customerId);
	  
  }
  
   
}
