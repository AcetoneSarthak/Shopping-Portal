package com.customerservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.customerservice.dto.OrderDetails;
import com.customerservice.dto.Orders;
import com.customerservice.dto.PaymentDetails;
import com.customerservice.dto.ViewCustomerDetails;
import com.customerservice.exception.CustomerNotFound;
import com.customerservice.model.Customer;
import com.customerservice.repository.CustomerRepository;

import jakarta.persistence.criteria.Order;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	CustomerRepository customerRepository;
	
	
	@Autowired
	OrderServiceCaller orderServiceCaller;
	
	@Autowired
	PaymentServiceCaller paymentServiceCaller;
	    

		List<Orders> ordersList = new ArrayList<>();
		
		
		
		public ViewCustomerDetails viewCustomerOrderDetails(String customerId) throws CustomerNotFound, InterruptedException, ExecutionException 
		{ 
			  Optional<Customer> customer = Optional.ofNullable(new Customer());
			 			  
			  customer= customerRepository.findById(customerId);
			  if(!customer.isPresent())
			  {
				  throw new CustomerNotFound("Customer Not Found");
			  }
			  ViewCustomerDetails viewCustomerDetails = new ViewCustomerDetails();
			  viewCustomerDetails.setCustomer(customer.get());
						
			  List<Orders> listOfOrders = new ArrayList<>();
			  
	
			  CompletableFuture<List<OrderDetails>> orderCompletableFuture = CompletableFuture.supplyAsync(() -> {
		            return  orderServiceCaller.getOrderByCustomerID(customerId);  
		        });

			  CompletableFuture<List<PaymentDetails>> paymentCompletableFuture = CompletableFuture.supplyAsync(() -> {
		            return  paymentServiceCaller.getPaymentDetailsByCustomerID(customerId);  
		        });

		        CompletableFuture allDoneFuture = CompletableFuture.allOf(orderCompletableFuture, paymentCompletableFuture);

		allDoneFuture.get(); 
		List<OrderDetails> orderList = orderCompletableFuture.get();
		List<PaymentDetails> paymentList = paymentCompletableFuture.get();
		  
				
				for(OrderDetails o : orderList )
				{
					
					Orders order = new Orders();
					
					order.setId(o.getid());
					order.setCustomerId(o.getCustomerId());
					order.setDeliveryDate(o.getOrderdate());
					order.setOrderdate(o.getOrderdate());
					order.setProductCategory(o.getProductCategory());
					order.setProductiId(o.getProductiId());
					order.setProductName(o.getProductName());
					order.setQuantity(o.getQuantity());
					order.setPaymentDetails(paymentList);
				
					listOfOrders.add(order);
					
				}
		
			
				viewCustomerDetails.setOrders(listOfOrders);
				
				
				return viewCustomerDetails;
		}

}
