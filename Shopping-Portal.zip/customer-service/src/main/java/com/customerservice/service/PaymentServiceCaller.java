package com.customerservice.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.customerservice.dto.PaymentDetails;

public interface PaymentServiceCaller {

	
	public List<PaymentDetails> getPaymentDetailsByOrderID(String orderId);
	public List<PaymentDetails> getPaymentDetailsByCustomerID(String customerId);
}
