package com.customerservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.customerservice.dto.Orders;
import com.customerservice.dto.PaymentDetails;
import com.customerservice.dto.ViewCustomerDetails;
import com.customerservice.exception.CustomerNotFound;
import com.customerservice.model.Customer;
import com.customerservice.service.CustomerServiceImpl;

@ExtendWith(MockitoExtension.class)

public class CustomerServiceImplTest {
	
	 String customerId = "CUS123";
	 
	 @Mock
	 CustomerServiceImpl customerServiceImpl;
	 
	 @DisplayName("Successfully Return Details of Customer and his order Details")
	 @Test
	public void testviewCustomerOrderDetails_returnCustomerAndOrderDetails() throws CustomerNotFound, InterruptedException, ExecutionException {
		
		 
		
		 List<Customer> customers = new ArrayList<>(
			        Arrays.asList(new Customer("CUS123", "Sarthak", "sarthak@gmail.com"),
			        		new Customer("CUS124", "Mustafa", "mustafa@gmail.com"),
			        		new Customer("CUS125", "Aditi", "aditi@gmail.com")));
			    
			    
			    PaymentDetails paymentDetails = new PaymentDetails();
			    paymentDetails.setId("PAY123");
			    paymentDetails.setCurrency("INR");
			    paymentDetails.setCustomerId("CUS123");
			    paymentDetails.setOrderId("ORD123");
			    paymentDetails.setPaymentAmount(200);
			    paymentDetails.setPaymentStatus("COMPLETED");
			    paymentDetails.setPaymentTime(LocalDateTime.now());
			    
			    Orders orders = new Orders();
			    orders.setCustomerId("CUS123");
			    orders.setDeliveryDate(LocalDate.now().plusDays(2));
			    orders.setOrderdate(LocalDate.now());
			    orders.setId("ORD123");
			    orders.setProductCategory("FMCG");
			    orders.setProductiId(UUID.randomUUID());
			    orders.setProductName("Lays");
			    orders.setQuantity(1);
			    
			    orders.setPaymentDetails(Arrays.asList(paymentDetails));
			    
			    ViewCustomerDetails viewCustomerDetails = new ViewCustomerDetails();
			    
			    viewCustomerDetails.setCustomer(customers.get(0));
			    viewCustomerDetails.setOrders(Arrays.asList(orders));
			    
			   
			    when(customerServiceImpl.viewCustomerOrderDetails(customerId)).thenReturn(viewCustomerDetails);
			    
			    assertEquals(customerId,customerServiceImpl.viewCustomerOrderDetails(customerId).getCustomer().getId());
		
	}

	 
	 @DisplayName("Customer Not Found Exception Testing")
	 @Test
		public void testviewCustomerOrderDetails_CustomerNotFound() throws CustomerNotFound, InterruptedException, ExecutionException {
	 
		 when(customerServiceImpl.viewCustomerOrderDetails(customerId)).thenThrow(CustomerNotFound.class);
		 assertThrows(CustomerNotFound.class, ()-> customerServiceImpl.viewCustomerOrderDetails(customerId));
}
}