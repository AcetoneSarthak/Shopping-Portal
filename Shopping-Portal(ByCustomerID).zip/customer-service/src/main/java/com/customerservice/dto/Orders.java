package com.customerservice.dto;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class Orders {
	
	String id;

	String customerId;
	

	LocalDate deliveryDate;
	
	
	UUID productiId ;
	

	String productCategory;

	String productName;
	

	LocalDate orderdate;
	
	int quantity;
	
	List<PaymentDetails> paymentDetails;

	public Orders() {
		super();
	}

	public Orders(String id, String customerId, LocalDate deliveryDate, UUID productiId, String productCategory,
			String productName, LocalDate orderdate, int quantity, List<PaymentDetails> paymentDetails) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.deliveryDate = deliveryDate;
		this.productiId = productiId;
		this.productCategory = productCategory;
		this.productName = productName;
		this.orderdate = orderdate;
		this.quantity = quantity;
		this.paymentDetails = paymentDetails;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public UUID getProductiId() {
		return productiId;
	}

	public void setProductiId(UUID productiId) {
		this.productiId = productiId;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public List<PaymentDetails> getPaymentDetails() {
		return paymentDetails;
	}

	public void setPaymentDetails(List<PaymentDetails> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	@Override
	public String toString() {
		return "Orders [id=" + id + ", customerId=" + customerId + ", deliveryDate=" + deliveryDate + ", productiId="
				+ productiId + ", productCategory=" + productCategory + ", productName=" + productName + ", orderdate="
				+ orderdate + ", quantity=" + quantity + ", paymentDetails=" + paymentDetails + "]";
	}

	

}
