package com.customerservice.service;

import java.util.concurrent.ExecutionException;

import com.customerservice.dto.ViewCustomerDetails;
import com.customerservice.exception.CustomerNotFound;

public interface CustomerService {

	public ViewCustomerDetails viewCustomerOrderDetails(String customerId) throws CustomerNotFound, InterruptedException, ExecutionException;
}
