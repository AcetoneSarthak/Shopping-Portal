package com.customerservice.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.customerservice.dto.PaymentDetails;

public interface PaymentServiceCaller {

	
	public CompletableFuture<List<PaymentDetails>> getPaymentDetailsByOrderID(String orderId);
}
