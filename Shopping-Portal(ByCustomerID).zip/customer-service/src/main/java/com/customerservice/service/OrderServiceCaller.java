package com.customerservice.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.customerservice.dto.OrderDetails;

public interface OrderServiceCaller {
	
	public CompletableFuture<List<OrderDetails>> getOrderByCustomerID(String customerId);

}
