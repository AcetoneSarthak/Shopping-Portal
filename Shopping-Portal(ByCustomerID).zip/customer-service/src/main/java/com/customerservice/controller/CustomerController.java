package com.customerservice.controller;

import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customerservice.dto.ViewCustomerDetails;
import com.customerservice.exception.CustomerNotFound;
import com.customerservice.model.Customer;
import com.customerservice.service.CustomerService;
import com.customerservice.service.CustomerServiceImpl;

@RestController
@RequestMapping("/customer-service")
public class CustomerController {
	

	private  CustomerServiceImpl customerService;
	
	private ViewCustomerDetails viewCustomerDetails;
	
	
	
	public CustomerController(CustomerServiceImpl customerService, ViewCustomerDetails viewCustomerDetails) {
		super();
		this.customerService = customerService;
		this.viewCustomerDetails = viewCustomerDetails;
	}



	@GetMapping("/viewCustomerOrders/{customerId}")
	public ResponseEntity<ViewCustomerDetails> viewCustomerDetails(@PathVariable("customerId") String customerId) throws InterruptedException, ExecutionException, CustomerNotFound
	{
	
		viewCustomerDetails = customerService.viewCustomerOrderDetails(customerId);
		  return new ResponseEntity<>(viewCustomerDetails,HttpStatus.OK);
		
		
	}
	

}
