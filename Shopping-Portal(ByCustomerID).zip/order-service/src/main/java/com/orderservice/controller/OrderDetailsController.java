package com.orderservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.orderservice.dto.OrderDetailsRequest;
import com.orderservice.model.OrderDetails;
import com.orderservice.service.OrderDetailsServiceImpl;



@RestController
@RequestMapping("/order-service")
public class OrderDetailsController {
	

	@Autowired
	OrderDetailsServiceImpl orderDetailsService;
	
	
  @PostMapping("/saveOrderDetails")
  @ResponseStatus(HttpStatus.CREATED)
  public void saveOrderDetails(@RequestBody OrderDetailsRequest orderDetailsRequest)
  {
	  orderDetailsService.saveOrderDetails(orderDetailsRequest);
  }
  
  @GetMapping("/getOrderDetails/{customerId}")
  public List<OrderDetails> getPaymentDetails(@PathVariable("customerId") String customerId) throws InterruptedException
  {
	  Thread.sleep(3000);
	  return orderDetailsService.getOrderDetails(customerId);
	  
  }

}
