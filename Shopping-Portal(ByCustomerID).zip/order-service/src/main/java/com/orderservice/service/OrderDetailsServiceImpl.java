package com.orderservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderservice.dto.OrderDetailsRequest;
import com.orderservice.model.OrderDetails;
import com.orderservice.repository.OrderDetailsRepository;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {
	
	@Autowired
	OrderDetailsRepository orderDetailsRepository;
	
	 public void saveOrderDetails(OrderDetailsRequest orderDetailsRequest)
	  {
		 OrderDetails orderDetails = new OrderDetails();
		 
		 orderDetails.setId(orderDetailsRequest.getOrderId());
		 
		 orderDetails.setCustomerId(orderDetailsRequest.getCustomerId());
		 
		 orderDetails.setDeliveryDate(orderDetailsRequest.getDeliveryDate());
		 
		 orderDetails.setOrderdate(orderDetailsRequest.getOrderdate());
		 
		 orderDetails.setProductCategory(orderDetailsRequest.getProductCategory());
		 
		 orderDetails.setProductiId(UUID.randomUUID().toString());
		 
		 orderDetails.setProductName(orderDetailsRequest.getProductName());
		 
		 orderDetails.setQuantity(orderDetailsRequest.getQuantity());
		 
		 orderDetailsRepository.save(orderDetails);
		 
		 
	  }
	 
	 public List<OrderDetails> getOrderDetails(String customerId)
	 {
		
		return orderDetailsRepository.findByCustomerId(customerId);
	 }
	

}
