package com.orderservice.exception;

public class OrderNotFound extends Exception {
	
	public OrderNotFound(String message)
	{
		super(message);
	}

}
