package com.orderservice.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(OrderNotFound.class)
	public ResponseEntity<ExceptionBody> handleAllExceptions(OrderNotFound ex)
	{
		
		ExceptionBody exceptionBody = new ExceptionBody(ex.getMessage(),404,LocalDateTime.now());
		
		return new ResponseEntity<>(exceptionBody, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionBody> handleAllExceptions(Exception ex)
	{
		
		ExceptionBody exceptionBody = new ExceptionBody(ex.getMessage(),420,LocalDateTime.now());
		
		return new ResponseEntity<>(exceptionBody, HttpStatus.BAD_REQUEST);
	}
}
