package com.orderservice.dto;

import java.time.LocalDate;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Id;

public class OrderDetailsRequest {
	
	String orderId;
	
	String customerId;
	

	LocalDate deliveryDate;
	
	UUID productId;

	String productCategory;

	String productName;
	

	LocalDate orderdate;
	
	int quantity;

	public OrderDetailsRequest() {
		super();
	}

	public OrderDetailsRequest(String orderId, String customerId, LocalDate deliveryDate, UUID productId,
			String productCategory, String productName, LocalDate orderdate, int quantity) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.deliveryDate = deliveryDate;
		this.productId = productId;
		this.productCategory = productCategory;
		this.productName = productName;
		this.orderdate = orderdate;
		this.quantity = quantity;
	}


	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public LocalDate getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(LocalDate deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public UUID getProductId() {
		return productId;
	}

	public void setProductId(UUID productId) {
		this.productId = productId;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


}
